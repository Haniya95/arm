package com.retro.calculator;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}